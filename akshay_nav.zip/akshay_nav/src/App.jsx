import Nav from "./components/navbar"

import Footer from "./components/Footer"

function App() {
  

  return (
    <>
    <Nav />
    <Footer />
    </>
  )
}

export default App;
